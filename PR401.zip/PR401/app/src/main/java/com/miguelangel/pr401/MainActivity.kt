package com.miguelangel.pr401
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CuadernoProfesorApp()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CuadernoProfesorApp() {
    var inputValue by remember { mutableStateOf("") }
    var outputText by remember { mutableStateOf("") }
    var cuaderno by remember { mutableStateOf(CuadernoProfesor()) }

    var notaToDelete by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        OutlinedTextField(
            value = inputValue,
            onValueChange = {
                inputValue = it
            },
            label = { Text("Nota") },
            singleLine = true,
            keyboardOptions = KeyboardOptions.Default.copy(
                imeAction = ImeAction.Done
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Button(
                onClick = {
                    if (inputValue.isNotEmpty()) {
                        val nota = inputValue.toDouble()
                        cuaderno.ponerNota(nota)
                        inputValue = ""
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .padding(8.dp)
            ) {
                Text("Poner Nota")
            }

            OutlinedTextField(
                value = notaToDelete,
                onValueChange = {
                    notaToDelete = it
                },
                label = { Text("Posición a borrar") },
                singleLine = true,
                keyboardOptions = KeyboardOptions.Default.copy(
                    imeAction = ImeAction.Done
                ),
                modifier = Modifier
                    .weight(1f)
                    .padding(8.dp)
            )

            Button(
                onClick = {
                    if (notaToDelete.isNotEmpty()) {
                        val posicion = notaToDelete.toIntOrNull()
                        if (posicion != null) {
                            cuaderno.borrarNotaEnPosicion(posicion)
                            notaToDelete = ""
                        }
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .padding(8.dp)
            ) {
                Text("Borrar Nota")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val media = cuaderno.calcularMediaQuitandoExtremos()
                outputText = "La media de la clase quitando la nota más alta y más baja es: $media"
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Text("Calcular Media")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                cuaderno.borrarTodasLasNotas()
                outputText = "Todas las notas han sido borradas."
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Text("Borrar Todas las Notas")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Valores actuales: ${cuaderno.mostrarNotas()}",
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))


        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = outputText,
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        )
    }
}

class CuadernoProfesor {
    private val MAX_NOTAS = 10
    private val notas = DoubleArray(MAX_NOTAS)
    private var cantidadNotas = 0

    fun ponerNota(nota: Double) {
        if (cantidadNotas < MAX_NOTAS) {
            notas[cantidadNotas++] = nota
        }
    }

    fun borrarNotaEnPosicion(posicion: Int) {
        if (posicion in 1..cantidadNotas) {
            for (i in posicion - 1 until cantidadNotas - 1) {
                notas[i] = notas[i + 1]
            }
            cantidadNotas--
        }
    }

    fun calcularMediaQuitandoExtremos(): Double {
        if (cantidadNotas < 3) {
            return 0.0
        }

        var suma = 0.0
        var minNota = notas[0]
        var maxNota = notas[0]

        for (i in 0 until cantidadNotas) {
            suma += notas[i]

            if (notas[i] < minNota) {
                minNota = notas[i]
            }

            if (notas[i] > maxNota) {
                maxNota = notas[i]
            }
        }

        return (suma - minNota - maxNota) / (cantidadNotas - 2)
    }
    fun mostrarNotas(): String {
        return notas.copyOfRange(0, cantidadNotas).joinToString(", ")
    }
    fun borrarTodasLasNotas() {
        for (i in 0 until cantidadNotas) {
            notas[i] = 0.0
        }
        cantidadNotas = 0
    }

}
