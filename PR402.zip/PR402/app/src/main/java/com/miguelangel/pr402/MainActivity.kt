package com.miguelangel.pr402

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PR402()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PR402() {
    var tipoVehiculo by remember { mutableStateOf("COCHE") }
    var cantidadRuedas by remember { mutableStateOf(0) }
    var motor by remember { mutableStateOf("") }
    var cantidadAsientos by remember { mutableStateOf(0) }
    var color by remember { mutableStateOf("") }
    var modelo by remember { mutableStateOf("") }
    var capacidadCarga by remember { mutableStateOf("") }

    var concesionario by remember { mutableStateOf(Concesionario()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val tipos = arrayOf("COCHE", "MOTO", "PATINETE")
            for (tipo in tipos) {
                TextButton(
                    onClick = {
                        tipoVehiculo = tipo
                    },
                    modifier = Modifier.padding(4.dp)
                ) {
                    Text(text = tipo)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val tiposFurgonetaTrailer = arrayOf("FURGONETA", "TRAILER")
            for (tipo in tiposFurgonetaTrailer) {
                TextButton(
                    onClick = {
                        tipoVehiculo = tipo
                    },
                    modifier = Modifier.padding(4.dp)
                ) {
                    Text(text = tipo)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Spacer(modifier = Modifier.height(16.dp))

        TextField(
            value = cantidadRuedas.toString(),
            onValueChange = {
                cantidadRuedas = it.toIntOrNull() ?: 0
            },
            label = { Text("Número de Ruedas") },
            keyboardOptions = KeyboardOptions.Default.copy(
                keyboardType = KeyboardType.Number,
                imeAction = ImeAction.Done
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        TextField(
            value = motor,
            onValueChange = { motor = it },
            label = { Text("Motor") },
            keyboardOptions = KeyboardOptions.Default.copy(
                imeAction = ImeAction.Done
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        if (tipoVehiculo != "PATINETE" && tipoVehiculo != "MOTO") {
            TextField(
                value = cantidadAsientos.toString(),
                onValueChange = { cantidadAsientos = it.toIntOrNull() ?: 0 },
                label = { Text("Número de Asientos") },
                keyboardOptions = KeyboardOptions.Default.copy(
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Done
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        TextField(
            value = color,
            onValueChange = { color = it },
            label = { Text("Color") },
            keyboardOptions = KeyboardOptions.Default.copy(
                imeAction = ImeAction.Done
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        TextField(
            value = modelo,
            onValueChange = { modelo = it },
            label = { Text("Modelo") },
            keyboardOptions = KeyboardOptions.Default.copy(
                imeAction = ImeAction.Done
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        if (tipoVehiculo == "FURGONETA" || tipoVehiculo == "TRAILER") {
            TextField(
                value = capacidadCarga,
                onValueChange = { capacidadCarga = it },
                label = { Text("Capacidad de Carga") },
                keyboardOptions = KeyboardOptions.Default.copy(
                    imeAction = ImeAction.Done
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val vehiculo = Vehiculo(tipoVehiculo, cantidadRuedas, motor, cantidadAsientos, color, modelo, capacidadCarga)
                concesionario.agregarVehiculo(vehiculo)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Crear Vehículo")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Número de COCHES: ${concesionario.obtenerCantidadVehiculosPorTipo("COCHE")}",
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Número de MOTOS: ${concesionario.obtenerCantidadVehiculosPorTipo("MOTO")}",
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Número de PATINETES: ${concesionario.obtenerCantidadVehiculosPorTipo("PATINETE")}",
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Número de FURGONETAS: ${concesionario.obtenerCantidadVehiculosPorTipo("FURGONETA")}",
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Número de TRAILERS: ${concesionario.obtenerCantidadVehiculosPorTipo("TRAILER")}",
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Listado de Vehículos por nombre:",
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        )

        ListaVehiculos(concesionario)
    }
}

@Composable
fun ListaVehiculos(concesionario: Concesionario) {
    Spacer(modifier = Modifier.height(16.dp))

    for (vehiculo in concesionario.obtenerListaVehiculosPorNombre()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
        ) {
            Text("Tipo: ${vehiculo.tipo}")
            Spacer(modifier = Modifier.width(8.dp))
            Text("Ruedas: ${vehiculo.cantidadRuedas}")
            Spacer(modifier = Modifier.width(8.dp))
            Text("Motor: ${vehiculo.motor}")
            Spacer(modifier = Modifier.width(8.dp))
            Text("Asientos: ${vehiculo.cantidadAsientos}")
            Spacer(modifier = Modifier.width(8.dp))
            Text("Color: ${vehiculo.color}")
            Spacer(modifier = Modifier.width(8.dp))
            Text("Modelo: ${vehiculo.modelo}")
            Spacer(modifier = Modifier.width(8.dp))
            Text("Carga: ${vehiculo.capacidadCarga}")
        }
    }
}

class Concesionario {
    private val MAX_VEHICULOS = 10
    private val vehiculos = Array<Vehiculo?>(MAX_VEHICULOS) { null }
    private var cantidadVehiculos = 0

    fun agregarVehiculo(vehiculo: Vehiculo) {
        if (cantidadVehiculos < MAX_VEHICULOS) {
            vehiculos[cantidadVehiculos++] = vehiculo
        }
    }

    fun obtenerCantidadVehiculosPorTipo(tipo: String): Int {
        var contador = 0
        for (vehiculo in vehiculos.filterNotNull()) {
            if (vehiculo.tipo == tipo) {
                contador++
            }
        }
        return contador
    }

    fun obtenerListaVehiculosPorNombre(): List<Vehiculo> {
        return vehiculos.filterNotNull().sortedBy { it.modelo }
    }
}

data class Vehiculo(
    val tipo: String,
    val cantidadRuedas: Int,
    val motor: String,
    val cantidadAsientos: Int,
    val color: String,
    val modelo: String,
    val capacidadCarga: String
)
